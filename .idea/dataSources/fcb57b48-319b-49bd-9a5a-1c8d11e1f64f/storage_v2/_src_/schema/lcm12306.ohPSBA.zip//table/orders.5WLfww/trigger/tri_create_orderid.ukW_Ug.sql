create definer = root@localhost trigger tri_create_orderId
    before insert
    on orders
    for each row
BEGIN
    #         定义临时变量
    DECLARE torderId VARCHAR(40); #订单编号
    DECLARE tcarType VARCHAR(2);#车型
    DECLARE tcarNumber VARCHAR(6);#车号
    DECLARE tSameCarCount INT ; #用于统计同一辆车的人，以此来编座位号
    DECLARE tseatNumber VARCHAR(3);#座位号
    DECLARE tstartDate VARCHAR(10);#发车日期
    DECLARE tstartTime VARCHAR(8);#发车时间
#         给变量赋值
    SELECT COUNT(*)+1 INTO tSameCarCount FROM orders WHERE carId=NEW.carId;
    SELECT carType INTO tcarType FROM car WHERE carId=NEW.carId;
    SELECT carNumber INTO tcarNumber FROM car WHERE carId=NEW.carId;
    SELECT startDate INTO tstartDate FROM car WHERE carId=NEW.carId;
    SELECT startTime INTO tstartTime FROM car WHERE carId=NEW.carId;
#         设定座位号格式
    IF tSameCarCount<10 THEN
        SET tseatNumber =CONCAT('00',tSameCarCount);
    END IF;
    IF (tSameCarCount>=10 AND tSameCarCount<100) THEN
        SET tseatNumber =CONCAT('0',tSameCarCount);
    END IF;
#         拼接成订单编号格式：车辆类型+车辆号+下单
    SET torderId = CONCAT(tcarType,tcarNumber,SUBSTRING(tstartDate,1,4),SUBSTRING(tstartDate,6,2),SUBSTRING(tstartDate,9,2),SUBSTRING(tstartTime,1,2),SUBSTRING(tstartTime,4,2),tseatNumber);
#         设置座位号
    SET NEW.orderId = torderId;
    SET NEW.seatNumber = tseatNumber;
#     更新车票余量
    UPDATE car SET ticketValue=ticketValue-1 WHERE carId=NEW.carId;
END;

