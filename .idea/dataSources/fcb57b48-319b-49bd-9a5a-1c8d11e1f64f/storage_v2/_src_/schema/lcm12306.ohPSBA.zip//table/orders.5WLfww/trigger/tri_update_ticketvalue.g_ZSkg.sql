create definer = root@localhost trigger tri_update_ticketValue
    before update
    on orders
    for each row
BEGIN
    IF(NEW.orderStatus=0) THEN
        UPDATE car SET ticketValue=ticketValue+1 WHERE carId=NEW.carId;
    END IF;
END;

